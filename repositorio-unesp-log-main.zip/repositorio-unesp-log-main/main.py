import json
from pandas import DataFrame
from handlers.log_xls_handler import extract_data_from_log_file_if_needed, analize_queries_if_needed, ExclusionRuleType
from handlers.utils import _get_nomes, _get_municipios
from handlers.text_handler import TextRuleType, get_text_combinations
from handlers.thesauro_handler import get_tesauro_if_needed
from handlers.keyword_crawler_handler import get_repositorio_if_needed, analize_keywords_if_needed
from handlers.compare_handler import compare_terms_if_needed

# -- [ Extração do Log ] --
# Define os parâmetros de extração do arquivo xlsx
_log_xlsx_file_input = 'data/raw/estatisticas-2sem20192.xlsx'
_log_json_file_input = 'data/products/' + _log_xlsx_file_input.split('/')[-1][0:-4] + 'json'
_log_clear_rules = {
    ':";\'=()[]-+&*/,.<>_`! ' : TextRuleType.STRIP_CHARS,
    r'^[0-9]+' : TextRuleType.REGEX,
    r'^(CHTTPS\:\/\/).*' : TextRuleType.REGEX
}
_log_force_extraction = False


# Cria a variável 'log_data' com o resultado da extração do arquivo de log xlsx
_log_data = extract_data_from_log_file_if_needed(
    xlsx_file_input=_log_xlsx_file_input,
    json_file_output=_log_json_file_input,
    clean_rules=_log_clear_rules,
    force_extraction=_log_force_extraction)

# Grava os dados da variável 'log_data' no arquivo json
with open(_log_json_file_input, "w") as _outfile:
        json.dump(_log_data, _outfile)

# -- [ Seleção dos Termos do Log ]
_terms_json_file_input = 'data/products/' + _log_xlsx_file_input.split('/')[-1][0:-4] + 'terms' + '.json'
_terms_exclusion_rules = {
    str(ExclusionRuleType.WORD_IN_LIST) : {
        'nomes' : _get_nomes(),
        'municípios' : _get_municipios()
    },
    str(ExclusionRuleType.MINIMUM_LENGTH) : 3,
    str(ExclusionRuleType.MAXIMUM_WORDS) : 5,
    str(ExclusionRuleType.NAMED_REGEX) : {
        'only_numbers' : r'^[0-9]+\.?[0-9]*$'
    }
}
_terms_force_analize = _log_force_extraction
_terms_file_output = 'data/products/' + _log_xlsx_file_input.split('/')[-1][0:-5] + '-TERMOS.xlsx'

log_terms = analize_queries_if_needed(
    log_data=_log_data,
    json_file_output=_terms_json_file_input,
    exclusion_rules=_terms_exclusion_rules,
    force_analize=_terms_force_analize) 

# Grava os dados da variável 'log_terms' no arquivo xlsx
_selected_log_dict = {'Termo' : [], 'Quantidade' : []}
for _k, _v in log_terms['SELECTED_TERMS'].items():
    _selected_log_dict['Termo'].append(_k)
    _selected_log_dict['Quantidade'].append(_v)
_df_terms_log = DataFrame(data=_selected_log_dict)
_df_terms_log.sort_values(by=['Termo']).to_excel(excel_writer=_terms_file_output, index=False)

# ============================================================================
# -- [ Importação do Thesauro ]
_thesauro_json_file_input = 'data/products/thesauro.json'
_thesauro_force_import = _log_force_extraction
_thesauro_file_output = 'data/products/Thesauro-TERMOS.xlsx'

thesauro_terms = get_tesauro_if_needed(
    json_file_output=_thesauro_json_file_input,
    force_import=_thesauro_force_import)

# Grava os dados da variável 'thesauro_terms' no arquivo xlsx
_selected_thesauro_dict = {'Termo' : []}
for _k, _v in thesauro_terms['terms'].items():
    _selected_thesauro_dict['Termo'].append(_v)
_df_terms_thesauro = DataFrame(data=_selected_thesauro_dict)
_df_terms_thesauro.sort_values(by=['Termo']).to_excel(excel_writer=_thesauro_file_output, index=False)

# ============================================================================
# -- [ Importação do Repositório de Palavas Chave ]
_repositorio_json_file_input = 'data/products/repositorio.json'
_repositorio_force_import = _log_force_extraction
_repositorio_file_output = 'data/products/Repositorio.xlsx'

_repositorio_terms = get_repositorio_if_needed(
    json_file_output=_repositorio_json_file_input,
    force_import=_repositorio_force_import)

# -- [ Seleção dos Termos do Repositório ]
_repositorio_json_file_input = 'data/products/repositorio.select.json'
_repositorio_exclusion_rules = {
    str(ExclusionRuleType.MINIMUM_LENGTH): 3,
    str(ExclusionRuleType.REGEX) : [r'^[0-9]+\-[0-9]+$', r'^[0-9]+\:[0-9]+$', r'^[0-9]+$']
}
_repositorio_force_analize = _log_force_extraction
_repositorio_file_output = 'data/products/Repositorio-TERMOS.xlsx'
_repositorio_min_count = 2

repositorio_terms = analize_keywords_if_needed(
    keyword_data=_repositorio_terms,
    json_file_output=_repositorio_json_file_input,
    exclusion_rules=_repositorio_exclusion_rules,
    min_count=_repositorio_min_count,
    force_analize=_repositorio_force_analize) 

# Grava os dados da variável 'log_terms' no arquivo xlsx
_selected_repositorio_dict = {'Termo' : [], 'Quantidade' : [], 'Documentos' : []}
for _k, _v in repositorio_terms['SELECTED_TERMS'].items():
    _selected_repositorio_dict['Termo'].append(_k)
    _selected_repositorio_dict['Quantidade'].append(_v['COUNT'])
    _selected_repositorio_dict['Documentos'].append(_v['NUM_DOCS'])
_df_terms_repositorio = DataFrame(data=_selected_repositorio_dict)
_df_terms_repositorio.sort_values(by=['Termo']).to_excel(excel_writer=_repositorio_file_output, index=False)

# ============================================================================
# -- [ Comparação dos Termos ]

_results_file_output = 'data/products/resultados.json'
_results_force_compare = True#_log_force_extraction

_list_thesauro = list(thesauro_terms['terms'].values())
for _item in list(thesauro_terms['alternative_terms'].values()):
    if _item not in _list_thesauro:
        _list_thesauro.append(_item)

results = compare_terms_if_needed(
    terms={
        'repositorio' : list(repositorio_terms['SELECTED_TERMS'].keys()),
        'log' : list(log_terms['SELECTED_TERMS'].keys()),
        'thesauro' : _list_thesauro
    },
    json_file_output=_results_file_output,
    force_compare=_results_force_compare)

# Grava os dados da variável 'results' nos arquivos xlsx
for _k, _v in results.items():
    _fileout = 'data/products/resultados-' + _k.replace(':', '_') + '.xlsx'
    _list_dict = {'Termo' : _v}
    _df_list = DataFrame(data=_list_dict)
    _df_list.sort_values(by=['Termo']).to_excel(excel_writer=_fileout, index=False)

# Grava os dados da variável 'results' nos arquivos xlsx
for _label in results.keys():
    _result_dict = {'Termo' : results[_label]}
    _df_result_dict = DataFrame(data = _result_dict)
    _df_result_dict.sort_values(by=['Termo']).to_excel(excel_writer='data/products/' + (_label.replace(':', '_')) + '.xlsx', index=False)

# Verifica se os termos exclusivos do log podem ter alguma relaçao com o thesauro
_stop_words = [
    'A', 'AS', 'O', 'OS', 'E', 'DA', 'DAS', 'DO', 'DOS', 'DE', 'PARA', 'NO', 'NOS' , 'NA', 'NAS', 'EM'
]
log_thesauro_possible_relation = {}
_log_thesauro_possible_relation_file_output = 'data/products/log_tesauro_rel.xlsx'

for _t in results['ONLY_log']:
    for _op in get_text_combinations(_t, _stop_words):
        if _op in _list_thesauro:
            if _t not in log_thesauro_possible_relation:
                log_thesauro_possible_relation[_t] = _op
            else:
                log_thesauro_possible_relation[_t] += '; ' + _op
        
# Grava os dados da variável 'log_thesauro_possible_relation' no arquivo xlsx
_log_thesauro_possible_relation_dict = {'Termo_Log' : [], 'Termo_Thesauro' : []}
for _k, _v in log_thesauro_possible_relation.items():
    _log_thesauro_possible_relation_dict['Termo_Log'].append(_k)
    _log_thesauro_possible_relation_dict['Termo_Thesauro'].append(_v)
_df_log_thesauro_possible_relation = DataFrame(data=_log_thesauro_possible_relation_dict)
_df_log_thesauro_possible_relation.sort_values(by=['Termo_Log']).to_excel(excel_writer=_log_thesauro_possible_relation_file_output, index=False)

# Verifica se os termos exclusivos do log podem ter alguma relaçao com o repositorio
log_repositorio_possible_relation = {}
_log_repositorio_possible_relation_file_output = 'data/products/log_repositorio_rel.xlsx'

for _t in results['ONLY_log']:
    for _op in get_text_combinations(_t, _stop_words):
        if _op in repositorio_terms['SELECTED_TERMS']:
            if _t not in log_repositorio_possible_relation:
                log_repositorio_possible_relation[_t] = _op
            else:
                log_repositorio_possible_relation[_t] += '; ' + _op

# Grava os dados da variável 'log_repositorio_possible_relation' no arquivo xlsx
_log_repositorio_possible_relation_dict = {'Termo_Log' : [], 'Termo_Repositorio' : []}
for _k, _v in log_repositorio_possible_relation.items():
    _log_repositorio_possible_relation_dict['Termo_Log'].append(_k)
    _log_repositorio_possible_relation_dict['Termo_Repositorio'].append(_v)
_df_log_repositorio_possible_relation = DataFrame(data=_log_repositorio_possible_relation_dict)
_df_log_repositorio_possible_relation.sort_values(by=['Termo_Log']).to_excel(excel_writer=_log_repositorio_possible_relation_file_output, index=False)

resultados = {
    "V1" : results["ONLY_log"],
    "V2" : results["ONLY_thesauro"],
    "V3" : results["ONLY_repositorio"],
    "V4" : results["log:repositorio"],
    "V5" : results["log:thesauro"],
    "V6" : results["repositorio:thesauro"],
    "V7" : results["ALL"]
}