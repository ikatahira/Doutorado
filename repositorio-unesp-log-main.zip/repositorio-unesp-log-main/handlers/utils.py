import csv

def _get_nomes():
    result = []
    ignore = ['DE', 'DO', 'DA', 'NA', 'NO']
    with open('./data/raw/nomes.csv', newline='', encoding='utf-8') as csvfile:
        spamreader = csv.reader(csvfile, delimiter=',' , quotechar='|')
        for row in spamreader:
            rowreader = csv.reader(row[0].splitlines(), delimiter= '|')
            for names in rowreader:
                for n in names:
                    if n.strip() != '' and n.strip() not in ignore:
                        result.append(n.upper())
    return result

def _get_municipios():
    result = []
    with open('./data/raw/municipios-brasil.csv', newline='', encoding='utf-8') as csvfile:
        spamreader = csv.reader(csvfile, delimiter=';')
        for row in spamreader:
            result.append(row[4].upper())
    return result