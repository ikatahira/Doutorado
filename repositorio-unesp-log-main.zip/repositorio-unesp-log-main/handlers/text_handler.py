import re
from enum import Enum
from itertools import permutations

class TextRuleType(Enum):
    PLAIN_TEXT = 'plain_text'
    REGEX = 'regex'
    STRIP_CHARS = 'strip_chars'

def strip_chars(text:str, chars:str):
    for c in list(chars):
        text = text.strip(c)
    return text

def clear_text(text:str, cleaning_text_rules:dict = {}):
    text = re.sub(r' {2,}', ' ', text)
    i = 0
    while True:
        if TextRuleType.STRIP_CHARS in cleaning_text_rules.values():
            text = strip_chars(
                text,
                list(cleaning_text_rules.keys())[list(cleaning_text_rules.values()).index(TextRuleType.STRIP_CHARS)])
        else:
            text = text.strip()
        if not text:
            break
        if i == len(cleaning_text_rules):
            break
        rule = list(cleaning_text_rules.keys())[i]
        rule_type = cleaning_text_rules[rule]
        if rule_type == TextRuleType.PLAIN_TEXT:
            m_text = text.replace(rule, '')
            if len(m_text) < len(text):
                i = -1
                text = m_text
        elif rule_type == TextRuleType.REGEX:
            m_text = re.sub(rule, '', text)
            if len(m_text) < len(text):
                i = -1
                text = m_text
        elif rule_type == TextRuleType.STRIP_CHARS:
            m_text = strip_chars(text, rule).strip()
            if len(m_text) < len(text):
                i = -1
                text = m_text
        i += 1
    return text

def get_text_without_words(text:str, stop_words:list):
    for w in stop_words:
        pattern = '^' + w + '\ '
        text = re.sub(pattern, '', text)
        pattern = ' ' + w + ' '
        text = re.sub(pattern, ' ', text)
        pattern = w + '$'
        text = re.sub(pattern, '', text)
    return text.strip()

def get_text_combinations(text:str, stop_words:list):
    result = []
    text = get_text_without_words(text, stop_words)
    words = text.strip().split(' ')
    elements = permutations(words)
    for p in list(elements):
        result.append(' '.join(list(p)).strip())
        for pos in range(1, len(words)):
            term = ' '.join(list(p)[pos:])
            if term not in result:
                result.append(term)
    return result