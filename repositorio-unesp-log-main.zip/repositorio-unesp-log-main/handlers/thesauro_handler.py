import os.path
import json
import string
import requests
import xml.etree.ElementTree as ET
import re
import time
from datetime import datetime
from unidecode import unidecode

def prepare_string(text:str):
    text = unidecode(re.sub(r'\([\w* ]*\)', '', text))
    if text.count(',') == 1:
        parts = text.split(',');
        text = parts[1].strip() + ' ' + parts[0].strip()
    return text.upper()

def get_tesauro():
    result = result = {'terms' : {}, 'alternative_terms' : {}, 'relationships' : {}, 'info' : {'average' : 0, 'count' : 0, 'count_words': 0}}
    
    def count_word(word: str):
        result['info']['count'] += 1
        result['info']['count_words'] += word.count(' ') + 1        

    # if len(result['terms']) == 0:
    for letter in string.ascii_lowercase[:26]:
        url = 'https://portal.biblioteca.unesp.br/tematres/vocab/services.php?task=letter&arg=' + letter
        r = requests.get(url)
        for child in ET.fromstring(r.content).iter('term'):
            if child.find('string').text is not None:
                s = prepare_string(child.find('string').text)
                if child.find('term_id').text not in result['terms']:
                    count_word(s)
                result['terms'][child.find('term_id').text] = s
    
    for number in range(0,10):
        url = 'https://portal.biblioteca.unesp.br/tematres/vocab/services.php?task=letter&arg=' + str(number)
        r = requests.get(url)
        for child in ET.fromstring(r.content).iter('term'):
            if child.find('string').text is not None:
                s = unidecode(child.find('string').text)
                if child.find('term_id').text not in result['terms']:
                    count_word(s)
                result['terms'][child.find('term_id').text] = s
            
    while True:
        try:
            for k, v in result['terms'].items():
                if k not in result['relationships']:
                    url = 'https://portal.biblioteca.unesp.br/tematres/vocab/services.php?task=fetchAlt&arg=' + k
                    r = requests.get(url)
                    result['relationships'][k] = []
                    for child in ET.fromstring(r.content).iter('term'):
                        result['alternative_terms'][child.find('term_id').text] = prepare_string(child.find('string').text)
                        result['relationships'][k].append(child.find('term_id').text)
            break
        except:
            print("  - Erro de Conexão")
            time.sleep(1)
            print("  - Tentando Novamente...")
            
    result['info']['average'] = result['info']['count_words'] / result['info']['count']
      
    return result

def get_tesauro_if_needed(
        json_file_output:str,
        force_import:bool = False):
    start_time = datetime.now()
    
    result = None
    
    json_file_exists = os.path.isfile(json_file_output)

    print('[ Importação do Thesauro - Thesauro ]')
    print('- JSON File: ' + json_file_output)
    print('-- ' + ('Arquivo encontrado' if json_file_exists else 'Arquivo não encontrado'))
    print('-Start Time: ' + str(start_time))
    
    if not force_import and json_file_exists:
        print(' - Bypassing the stage')
        with open(json_file_output, 'r') as input:
            result =  json.load(input)
    else:
        print(' - Executing the stage')
        result = get_tesauro()
        # Grava os dados da variável 'result' no arquivo json
        with open(json_file_output, "w") as _outfile:
                json.dump(result, _outfile)

    end_time = datetime.now()
    print('-End Time: ' + str(end_time))
    print('-Execution Time:' + str(end_time - start_time))
    
    return result
    