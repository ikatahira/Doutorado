import os.path
import json
import pandas as pd
import re
from enum import Enum
from datetime import datetime
from urllib.parse import unquote
from handlers.text_handler import clear_text
from unidecode import unidecode

class ExclusionRuleType(Enum):
    WORD_IN_LIST = 'word_in_list'
    MINIMUM_LENGTH = 'minimum_length'
    MAXIMUM_WORDS = 'maximum_words'
    NAMED_REGEX = 'named_regex'
    REGEX = 'regex'

# Retorna uma lista com os dados constantes no arquivo XLSX
def extract_data_from_log_file(
    xlsx_file_input:str,
    clean_rules:list = []):
    
    # Define os campos do arquivo XLSX que serão analizados
    select_fields:list = ['ip', 'time', 'query', 'id']
    # Cria a variável que será retornada ao final da execução
    result = []
    
    # Função interna para estruturar os dados das consultas (retorna um dicionário)
    def _parse_query(query_string:str):
        # Cria a variável que será retornada ao final da execução
        _parse_query_result = {'_PLAIN_TEXT_QUERY' : query_string}
        
        items = []
        for segment in query_string.split(','):
            segment = unidecode(unquote(segment.replace('\\', '').replace('/**/', ' ')).strip('\'').strip('\"').strip())
            if '_keyword:' in segment:
                items.append(segment)
            else:
                if len(items) == 0:
                    items.append('')
                else:
                    items[-1] += ', '
                items[-1] += clear_text(segment.upper(), clean_rules)
        if len(items) > 0:
            _parse_query_result['_QUERY_TEXT'] = items
        # Retorna o resultado da execução
        return _parse_query_result
    
    # Lê os dados do arquivo XLSX criando um DataFrame
    df_dados = pd.read_excel(xlsx_file_input, dtype='unicode')
    
    # Percorre as linhas do DataFrame
    for k, v in df_dados.iterrows():
        row = {}
        for label, value in v.items():
            if label in select_fields:
                if value:
                    if label == 'query':
                        value = _parse_query(value)
                    row[label] = value
        if len(row) > 0:
            result.append(row)

    # Retorna o resultado da execuçao    
    return result

def extract_data_from_log_file_if_needed(
    xlsx_file_input:str,
    json_file_output:str = None,
    clean_rules:list = [],
    force_extraction: bool = False):
    start_time = datetime.now()
    
    result = None
    
    if json_file_output is None:
        json_file_output = 'data/products/' + xlsx_file_input.split('/')[-1][0:-4] + 'json'
    
    xlsx_file_exists = os.path.isfile(xlsx_file_input)
    json_file_exists = os.path.isfile(json_file_output)

    print('[ Extração de Dados - LOG ]')
    print('- XLSX File: ' + xlsx_file_input)
    print('-- ' + ('Arquivo encontrado' if xlsx_file_exists else 'Arquivo não encontrado'))
    print('- JSON File: ' + json_file_output)
    print('-- ' + ('Arquivo encontrado' if json_file_exists else 'Arquivo não encontrado'))
    print('-Start Time: ' + str(start_time))
    
    if not force_extraction and json_file_exists:
        print(' - Bypassing the stage')
        with open(json_file_output, 'r') as input:
            result =  json.load(input)
    else:
        print(' - Executing the stage')
        result = extract_data_from_log_file(xlsx_file_input=xlsx_file_input, clean_rules=clean_rules)

    end_time = datetime.now()
    print('-End Time: ' + str(end_time))
    print('-Execution Time:' + str(end_time - start_time))
    
    return result

def analize_queries(
        log_data:dict,
        exclusion_rules:dict):
    
    def _is_valid(term:str):
        _is_valid_result = {'result' : True, 'rule' : None}
        for rule_type, rule_content in exclusion_rules.items():
            if rule_type == str(ExclusionRuleType.MINIMUM_LENGTH):
                if(len(term) < rule_content):
                    _is_valid_result['result'] = False
                    _is_valid_result['rule'] = 'minimum_length (' + str(rule_content) + ')'
            elif rule_type == str(ExclusionRuleType.REGEX):
                for rule_regex in rule_content:
                    if not _is_valid_result['result']:
                        break
                    if re.match(rule_regex, str(term)) != None:
                        _is_valid_result['result'] = False                    
                        _is_valid_result['rule'] = 'regex'
            elif rule_type == str(ExclusionRuleType.NAMED_REGEX):
                for rule_name, rule_regex in rule_content.items():
                    if not _is_valid_result['result']:
                        break
                    if re.match(rule_regex, str(term)) != None:
                        _is_valid_result['result'] = False
                        _is_valid_result['rule'] = rule_name + ' (' + str(rule_regex) + ')' + ')'
            elif rule_type == str(ExclusionRuleType.MAXIMUM_WORDS):
                if term.count(' ') > rule_content:
                    _is_valid_result['result'] = False
                    _is_valid_result['rule'] = 'maximum_words (' + str(rule_content) + ')' + ')'
            elif rule_type == str(ExclusionRuleType.WORD_IN_LIST):
                for rule_name, rule_list in rule_content.items():
                    for word in term.split(' '):
                        if not _is_valid_result['result']:
                            break
                        if word in rule_list:
                            _is_valid_result['result'] = False
                            _is_valid_result['rule'] = rule_name
                            break
            if not _is_valid_result['result']:
                break
        return _is_valid_result
    
    result = {'ALL_TERMS' : {}, 'SELECTED_TERMS' : {}, 'UNSELECTED_TERMS' : {}, 'SELECTED_TERMS_INFO' : {'AVERAGE' : 0, 'COUNT' : 0, 'COUNT_WORDS' : 0}}
    for item in log_data:
        for k, v in item['query'].items():
            if k == '_QUERY_TEXT':
                for term in v:
                    key = term.upper().strip('\"')
                    if key not in result:
                        result['ALL_TERMS'][key] = {'_COUNT' : 1}
                    else:
                        result['ALL_TERMS'][key]['_COUNT'] += 1
                    if term not in result['ALL_TERMS'][key]:
                        result['ALL_TERMS'][key][term] = []
                    result['ALL_TERMS'][key][term].append(item)
                    is_valid = _is_valid(key)
                    if(is_valid['result']):
                        if key not in result['SELECTED_TERMS']:
                            result['SELECTED_TERMS'][key] = 1
                            result['SELECTED_TERMS_INFO']['COUNT'] += 1
                            result['SELECTED_TERMS_INFO']['COUNT_WORDS'] += key.count(' ') + 1
                        else:
                            result['SELECTED_TERMS'][key] += 1
                    else:
                        if is_valid['rule'] not in result['UNSELECTED_TERMS']:
                            result['UNSELECTED_TERMS'][is_valid['rule']] = {}
                        if key not in result['UNSELECTED_TERMS'][is_valid['rule']]:
                            result['UNSELECTED_TERMS'][is_valid['rule']][key] = 1
                        else:
                            result['UNSELECTED_TERMS'][is_valid['rule']][key] += 1
    
    result['SELECTED_TERMS_INFO']['AVERAGE'] = result['SELECTED_TERMS_INFO']['COUNT_WORDS'] / result['SELECTED_TERMS_INFO']['COUNT']
    return result

def analize_queries_if_needed(
    log_data:dict,
    json_file_output:str,
    exclusion_rules:dict,
    force_analize: bool = False):
    start_time = datetime.now()
    
    result = None
    
    json_file_exists = os.path.isfile(json_file_output)

    print('[ Seleção de Termos - LOG ]')
    print('- JSON File: ' + json_file_output)
    print('-- ' + ('Arquivo encontrado' if json_file_exists else 'Arquivo não encontrado'))
    print('-Start Time: ' + str(start_time))
    
    if not force_analize and json_file_exists:
        print(' - Bypassing the stage')
        with open(json_file_output, 'r') as input:
            result =  json.load(input)
    else:
        print(' - Executing the stage')
        result = analize_queries(log_data=log_data, exclusion_rules=exclusion_rules)
        # Grava os dados da variável 'result' no arquivo json
        with open(json_file_output, "w") as _outfile:
                json.dump(result, _outfile)

    end_time = datetime.now()
    print('-End Time: ' + str(end_time))
    print('-Execution Time:' + str(end_time - start_time))
    
    return result