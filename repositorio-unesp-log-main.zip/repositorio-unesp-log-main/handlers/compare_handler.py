import os.path
import json
from datetime import datetime

def compare_terms(terms:dict):
    result = {}
    list_labels = list(terms.keys())
                    
    for i in range(0, len(list_labels) - 1):
        if len(terms[list_labels[i]]) > len(terms[list_labels[i+1]]):
            temp = list_labels[i]
            list_labels[i] = list_labels[i+1]
            list_labels[i+1] = temp
            i = 0
    
    for l in list_labels:
        for term in terms[l]:
            in_list = []
            for k, v in terms.items():
                if k != l:
                    if term in v:
                        in_list.append(k)
            if len(in_list) == 0:
                label = 'ONLY_' + l
                if label not in result:
                    result[label] = []
                result[label].append(term)
            elif len(in_list) == (len(list_labels) - 1):
                label = 'ALL'
                if label not in result:
                    result[label] = []
                result[label].append(term)
            else:
                for name in in_list:
                    label = name + ':' + l
                    if label not in result:
                        label = l + ':' + name
                        if label not in result:
                            result[label] = []
                        result[label].append(term)
    
    return result

def compare_terms_if_needed(
        terms:dict,
        json_file_output:str,
        force_compare = False):
    
    start_time = datetime.now()
    
    result = None
    
    json_file_exists = os.path.isfile(json_file_output)

    print('[ Comparação dos Termos ]')
    print('- JSON File: ' + json_file_output)
    print('-- ' + ('Arquivo encontrado' if json_file_exists else 'Arquivo não encontrado'))
    print('-Start Time: ' + str(start_time))
    
    if not force_compare and json_file_exists:
        print(' - Bypassing the stage')
        with open(json_file_output, 'r') as input:
            result =  json.load(input)
    else:
        print(' - Executing the stage')
        result = compare_terms(terms=terms)
        # Grava os dados da variável 'result' no arquivo json
        with open(json_file_output, "w") as _outfile:
                json.dump(result, _outfile)

    end_time = datetime.now()
    print('-End Time: ' + str(end_time))
    print('-Execution Time:' + str(end_time - start_time))
    
    return result