import requests
import os.path
import json
import re
from bs4 import BeautifulSoup
from datetime import datetime
from handlers.log_xls_handler import ExclusionRuleType
from unidecode import unidecode

def get_repositorio():
    offset = 0      # Ponteiro de início de páginação
    npp = 10000     # Número de ítens por página
    
    keywords = {}   # Dicionário que armazenará as palavras-chave encontradas
    
    while(True):
        # Variável que armazenará a string HTML da página
        html = ''
        # URL à ser consultada adicionando o "npp" e "offset" atuais
        url = 'https://repositorio.unesp.br/browse?rpp='+str(npp)+'&sort_by=-1&type=subject&offset='+str(offset)+'&etal=-1&order=ASC'
        # Realiza a requisição HTTP e armazena o retorno em "req"
        req = requests.get(url)
        # Captura o texto da página (HTML) para a variável "html"
        html = req.text
        # Realiza o parser do "html" retornando um objeto navegável em "soup"
        soup = BeautifulSoup(html, 'html.parser')
        # Localiza a quantidade máxima de keywords, descrita em um ítem do HTML recebido, e armazena em "num_max"
        num_max = soup.find('p', attrs={"class": "pagination-info"}).text.split('de')[-1]
        
        # Localiza as palavras chaves na página HTML com base nas classes utilizadas para formatação e processa uma a uma
        for kw in soup.find_all('td', attrs={"class": "ds-table-cell odd"}):
            # Verifica se a palavra sendo processada não está no catálogo (variável keywords)
            kw_clean = unidecode(kw.a.text.strip("'").strip('"').upper())
            if kw_clean not in keywords.keys():
                # Caso verdadeiro adiciona a palavra com um contador "1"
                keywords[kw_clean] = {'COUNT' : 1, 'NUM_DOCS': int(re.search(r'\[\d+\]', kw.text).group(0)[1:-1])}
            else:
                # Caso contrário soma 1 ao contador relacionado à palavra
                keywords[kw_clean]['COUNT'] += 1
                keywords[kw_clean]['NUM_DOCS'] += int(re.search(r'\[\d+\]', kw.text).group(0)[1:-1])
        # Incrementa a variável "offset" com o valor de "npp"
        offset += npp
        # Verifica se o "offset" é maior que o valor de "num_max"
        if offset > int(num_max):
            # Caso verdadeiro, encerra a execução do loop "while"
            break;
        
    return keywords

def get_repositorio_if_needed(
        json_file_output:str,
        force_import:bool = False):
    start_time = datetime.now()
    
    result = None
    
    json_file_exists = os.path.isfile(json_file_output)

    print('[ Importação do Repositório - Keywords ]')
    print('- JSON File: ' + json_file_output)
    print('-- ' + ('Arquivo encontrado' if json_file_exists else 'Arquivo não encontrado'))
    print('-Start Time: ' + str(start_time))
    
    if not force_import and json_file_exists:
        print(' - Bypassing the stage')
        with open(json_file_output, 'r') as input:
            result =  json.load(input)
    else:
        print(' - Executing the stage')
        result = get_repositorio()
        # Grava os dados da variável 'result' no arquivo json
        with open(json_file_output, "w") as _outfile:
                json.dump(result, _outfile)

    end_time = datetime.now()
    print('-End Time: ' + str(end_time))
    print('-Execution Time:' + str(end_time - start_time))
    
    return result

def analize_keywords(
    keyword_data:dict,
    exclusion_rules:dict,
    min_count:int = 0,
    force_analize: bool = False):
    
    def _is_valid(term:str):
        _is_valid_result = {'result' : True, 'rule' : None}
        for rule_type, rule_content in exclusion_rules.items():
            if rule_type == str(ExclusionRuleType.MINIMUM_LENGTH):
                if(len(term) < rule_content):
                    _is_valid_result['result'] = False
                    _is_valid_result['rule'] = 'minimum_length (' + str(rule_content) + ')'
            elif rule_type == str(ExclusionRuleType.REGEX):
                for rule_regex in rule_content:
                    if not _is_valid_result['result']:
                        break
                    if re.match(rule_regex, str(term)) != None:
                        _is_valid_result['result'] = False                    
                        _is_valid_result['rule'] = 'regex'
            elif rule_type == str(ExclusionRuleType.NAMED_REGEX):
                for rule_name, rule_regex in rule_content.items():
                    if not _is_valid_result['result']:
                        break
                    if re.match(rule_regex, str(term)) != None:
                        _is_valid_result['result'] = False
                        _is_valid_result['rule'] = rule_name + ' (' + str(rule_regex) + ')' + ')'
            elif rule_type == str(ExclusionRuleType.MAXIMUM_WORDS):
                if term.count(' ') > rule_content:
                    _is_valid_result['result'] = False
                    _is_valid_result['rule'] = 'maximum_words (' + str(rule_content) + ')' + ')'
            elif rule_type == str(ExclusionRuleType.WORD_IN_LIST):
                for rule_name, rule_list in rule_content.items():
                    for word in term.split(' '):
                        if not _is_valid_result['result']:
                            break
                        if word in rule_list:
                            _is_valid_result['result'] = False
                            _is_valid_result['rule'] = rule_name
                            break
            if not _is_valid_result['result']:
                break
        return _is_valid_result
    
    result = {'ALL_TERMS' : keyword_data, 'SELECTED_TERMS' : {}, 'UNSELECTED_TERMS' : {}, 'SELECTED_TERMS_INFO' : {'AVERAGE' : 0, 'COUNT' : 0, 'COUNT_WORDS' : 0}}
    
    for k, v in keyword_data.items():
        if(min_count == 0 or v['COUNT'] >= min_count):
            is_valid = _is_valid(k)
            if is_valid:
                result['SELECTED_TERMS'][k] = v
                result['SELECTED_TERMS_INFO']['COUNT'] += 1
                result['SELECTED_TERMS_INFO']['COUNT_WORDS'] += k.count(' ') + 1
            else:
                if is_valid['rule'] in result['UNSELECTED_TERMS']:
                    result['UNSELECTED_TERMS'][is_valid['rule']] = {}
                result['UNSELECTED_TERMS'][is_valid['rule']][k] = v
        else:
            key = 'MIN_COUNT:' + str(min_count)
            if key not in result['UNSELECTED_TERMS']:
                result['UNSELECTED_TERMS'][key] = {}        
            result['UNSELECTED_TERMS'][key][k] = v
    result['SELECTED_TERMS_INFO']['AVERAGE'] = result['SELECTED_TERMS_INFO']['COUNT_WORDS'] / result['SELECTED_TERMS_INFO']['COUNT']
    return result

def analize_keywords_if_needed(
    keyword_data:dict,
    json_file_output:str,
    exclusion_rules:dict,
    min_count:int = 0,
    force_analize: bool = False):
    start_time = datetime.now()
    
    result = None
    
    json_file_exists = os.path.isfile(json_file_output)

    print('[ Seleção de Termos do Repositório - Keywords ]')
    print('- JSON File: ' + json_file_output)
    print('-- ' + ('Arquivo encontrado' if json_file_exists else 'Arquivo não encontrado'))
    print('-Start Time: ' + str(start_time))
    
    if not force_analize and json_file_exists:
        print(' - Bypassing the stage')
        with open(json_file_output, 'r') as input:
            result =  json.load(input)
    else:
        print(' - Executing the stage')
        result = analize_keywords(
            keyword_data=keyword_data, exclusion_rules=exclusion_rules, min_count = min_count)
        # Grava os dados da variável 'result' no arquivo json
        with open(json_file_output, "w") as _outfile:
                json.dump(result, _outfile)

    end_time = datetime.now()
    print('-End Time: ' + str(end_time))
    print('-Execution Time:' + str(end_time - start_time))
    
    return result